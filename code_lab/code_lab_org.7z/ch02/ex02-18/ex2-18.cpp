#include <iostream>
using namespace std ;
int main()
{
	for (int i = 32; i<128; i++)
   	cout << (char) i;
  		return 0;
}